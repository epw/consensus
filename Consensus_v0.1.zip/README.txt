Consensus version 0.1

The default rulebook to read is consensus_screen.pdf

If you want to read in a typeface designed to combat common symptoms of dyslexia, try one of the pdfs labeled dyslexic

If you want to read light text on a dark background, read one of the pdfs labeled hc

The Basic and Extended moves are on moves.pdf

When you are finished, please write feedback on the book here: https://forms.gle/yx7DBJLEQ63MwhAv8

If you play a game, please send all players here to write feedback: https://forms.gle/iSodkQVCky62A4Gy7
